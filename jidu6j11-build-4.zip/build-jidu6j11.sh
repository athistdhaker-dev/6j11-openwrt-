#!/bin/bash
# ============================================================
# JioRouter AX6000 JIDU6J11 family build script
# Firmware: OpenWrt only
# Devices:  jidu6j11-6111 / 6411 / 6611 / 6811 / 6911
# Chipset:  Qualcomm IPQ9554 (qualcommbe/ipq95xx target)
# Base:     OpenWrt MASTER / snapshot branch — REQUIRED.
#           openwrt-25.12 stable only carries kernel 6.12 under
#           target/linux/generic/ — this device's PR (#25869)
#           ships patches-6.18, which stable has no kernel
#           version/hash entry for at all, so it CANNOT be
#           built from the stable branch. Master is the only
#           option until OpenWrt itself backports kernel 6.18
#           to a future stable release.
#
# This script fetches PR #25869 LIVE from GitHub (not bundled
# static files) and cherry-picks its commits onto a fresh
# master checkout, skipping any commit that fails to apply
# (resilient cherry-pick, same pattern as the jidu6101/jidu6j01
# build scripts).
#
# Usage:
#   ./build-jidu6j11.sh <6111|6411|6611|6811|6911|all>
# ============================================================

set -e

DEVICE_ARG="$1"
VALID_DEVICES="6111 6411 6611 6811 6911"

if [ -z "$DEVICE_ARG" ]; then
    echo "Usage: $0 <6111|6411|6611|6811|6911|all>"
    exit 1
fi

if [ "$DEVICE_ARG" = "all" ]; then
    DEVICES="$VALID_DEVICES"
else
    DEVICES="$DEVICE_ARG"
    case " $VALID_DEVICES " in
        *" $DEVICE_ARG "*) ;;
        *) echo "Invalid device: $DEVICE_ARG (valid: $VALID_DEVICES or all)"; exit 1 ;;
    esac
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PKG_LIST_FILE="$SCRIPT_DIR/packages.txt"
REPO_URL="https://github.com/openwrt/openwrt.git"
PR_NUMBER="25869"

if [ ! -f "$PKG_LIST_FILE" ]; then
    echo "ERROR: packages.txt not found next to this script."
    exit 1
fi

build_one() {
    local DEV="$1"
    local SRC_DIR="$SCRIPT_DIR/build-jidu6j11-$DEV"

    echo "============================================================"
    echo " Building OpenWrt — JIDU6J11-$DEV"
    echo "============================================================"

    if [ ! -d "$SRC_DIR" ]; then
        echo "[*] Cloning OpenWrt main (full history for cherry-pick) ..."
        git clone https://github.com/openwrt/openwrt.git "$SRC_DIR"
    else
        echo "[*] Resetting existing checkout to latest main ..."
        (cd "$SRC_DIR" && git fetch origin main && git reset --hard origin/main && git clean -fd)
    fi

    cd "$SRC_DIR"

    echo "[*] Fetching PR #$PR_NUMBER live from GitHub ..."
    git fetch origin "pull/$PR_NUMBER/head:pr-$PR_NUMBER" --force

    echo "[*] Cherry-picking PR #$PR_NUMBER commits onto main (resilient, skips conflicts) ..."
    for commit in $(git log --reverse --format=%H "main..pr-$PR_NUMBER"); do
        if git cherry-pick --allow-empty -x "$commit" 2>/tmp/cherrypick-err.log; then
            echo "    applied: $commit"
        else
            echo "    SKIPPED (conflict): $commit"
            git cherry-pick --abort 2>/dev/null || true
        fi
    done

    # NOTE: no custom model-name script needed. Each JIDU6J11 variant's
    # own .dts already sets "model = ..." directly (e.g. "JioRouter
    # AX6000 JIDU6J11-6411"), unlike JIDU6J01 where one DTS covers 4
    # physical SKUs and needs a runtime MFG-partition scan. OpenWrt
    # shows the DTS model string automatically, no script required.
    echo "[*] Baking uci-defaults script + Aurora theme into files/ ..."
    mkdir -p files/etc/uci-defaults files/etc/custom-pkgs
    cp "$SCRIPT_DIR/99-jiorouter-jidu6j11-setup.txt" files/etc/uci-defaults/99-custom-config
    chmod +x files/etc/uci-defaults/99-custom-config
    cp "$SCRIPT_DIR/custom-pkgs/"*.apk files/etc/custom-pkgs/

    echo "[*] Updating feeds ..."
    ./scripts/feeds update -a
    ./scripts/feeds install -a

    echo "[*] Writing .config for jidu6j11-$DEV (target + full package list) ..."
    {
        echo "CONFIG_TARGET_qualcommbe=y"
        echo "CONFIG_TARGET_qualcommbe_ipq95xx=y"
        echo "CONFIG_TARGET_qualcommbe_ipq95xx_DEVICE_jiorouter_ax6000-jidu6j11-${DEV}=y"
        echo "# CONFIG_PACKAGE_luci-app-attendedsysupgrade is not set"
        echo "# CONFIG_PACKAGE_attendedsysupgrade-common is not set"
        for pkg in $(cat "$PKG_LIST_FILE"); do
            echo "CONFIG_PACKAGE_${pkg}=y"
        done
    } > .config

    make defconfig

    echo "[*] Downloading sources ..."
    make download -j$(nproc)

    echo "[*] Building (this will take a while) ..."
    make -j$(nproc) || make -j1 V=s

    cd "$SCRIPT_DIR"
    echo "[*] Build finished: jidu6j11-$DEV"
}

for D in $DEVICES; do
    build_one "$D"
done

echo "============================================================"
echo " ALL REQUESTED BUILDS COMPLETE"
echo "============================================================"
for D in $DEVICES; do
    echo " - build-jidu6j11-$D/bin/targets/qualcommbe/ipq95xx/"
done
