#!/bin/bash
# ============================================================
# JioRouter AX6000 JIDU6J11 family build script
# Firmware: OpenWrt only
# Devices:  jidu6j11-6111 / 6411 / 6611 / 6811 / 6911
# Chipset:  Qualcomm IPQ9554 (qualcommbe/ipq95xx target)
# Base:     OpenWrt MASTER / snapshot branch — REQUIRED, because
#           this device's kernel patches are for kernel 6.18,
#           which is not yet in the openwrt-25.12 stable branch
#           (still on kernel 6.12 there).
#
# IMPORTANT: this script does NOT fetch the PR from GitHub.
# It copies the already-extracted PR files from ./pr-files/
# directly on top of a fresh checkout.
#
# Usage:
#   ./build-jidu6j11.sh <6111|6411|6611|6811|6911|all>
# ============================================================

set -e

DEVICE_ARG="$1"
VALID_DEVICES="6111 6411 6611 6811 6911"

if [ -z "$DEVICE_ARG" ]; then
    echo "Usage: $0 <6111|6411|6611|6811|6911|all>"
    exit 1
fi

if [ "$DEVICE_ARG" = "all" ]; then
    DEVICES="$VALID_DEVICES"
else
    DEVICES="$DEVICE_ARG"
    case " $VALID_DEVICES " in
        *" $DEVICE_ARG "*) ;;
        *) echo "Invalid device: $DEVICE_ARG (valid: $VALID_DEVICES or all)"; exit 1 ;;
    esac
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PR_FILES="$SCRIPT_DIR/pr-files"

if [ ! -d "$PR_FILES" ]; then
    echo "ERROR: pr-files/ folder not found next to this script."
    exit 1
fi

REPO_URL="https://github.com/openwrt/openwrt.git"

build_one() {
    local DEV="$1"
    local SRC_DIR="$SCRIPT_DIR/build-jidu6j11-$DEV"

    echo "============================================================"
    echo " Building OpenWrt — JIDU6J11-$DEV"
    echo "============================================================"

    if [ ! -d "$SRC_DIR" ]; then
        echo "[*] Cloning OpenWrt master into $SRC_DIR ..."
        git clone --depth 1 "$REPO_URL" "$SRC_DIR"
    else
        echo "[*] Updating existing checkout ..."
        (cd "$SRC_DIR" && git fetch origin master --depth 1 && git reset --hard origin/master)
    fi

    echo "[*] Copying PR #25869 files directly onto the tree (no git fetch/cherry-pick) ..."
    cp -r "$PR_FILES"/. "$SRC_DIR"/

    cd "$SRC_DIR"

    echo "[*] Baking uci-defaults script + Aurora theme into files/ ..."
    mkdir -p files/etc/uci-defaults files/etc/custom-pkgs
    cp "$SCRIPT_DIR/99-jiorouter-jidu6j11-setup.txt" files/etc/uci-defaults/99-custom-config
    chmod +x files/etc/uci-defaults/99-custom-config
    cp "$SCRIPT_DIR/custom-pkgs/"*.apk files/etc/custom-pkgs/

    echo "[*] Updating feeds ..."
    ./scripts/feeds update -a
    ./scripts/feeds install -a

    echo "[*] Writing .config for jidu6j11-$DEV ..."
    cat > .config << EOF
CONFIG_TARGET_qualcommbe=y
CONFIG_TARGET_qualcommbe_ipq95xx=y
CONFIG_TARGET_qualcommbe_ipq95xx_DEVICE_jiorouter_ax6000-jidu6j11-${DEV}=y
# CONFIG_PACKAGE_luci-app-attendedsysupgrade is not set
# CONFIG_PACKAGE_attendedsysupgrade-common is not set
EOF

    make defconfig

    echo "[*] Downloading sources ..."
    make download -j$(nproc)

    echo "[*] Building (this will take a while) ..."
    make -j$(nproc) FILES=files || make -j1 V=s FILES=files

    cd "$SCRIPT_DIR"
    echo "[*] Build finished: jidu6j11-$DEV"
}

for D in $DEVICES; do
    build_one "$D"
done

echo "============================================================"
echo " ALL REQUESTED BUILDS COMPLETE"
echo "============================================================"
for D in $DEVICES; do
    echo " - build-jidu6j11-$D/bin/targets/qualcommbe/ipq95xx/"
done
